<?php

namespace App\model;

/**
 * 数据模型类演示
 * Class UserModel
 * @package App\Model
 */
class UserModel
{

    public function registerUser()
    {

    }

}