<?php
/**
 * 返回数组
 */
return [
    'wechat' => [
        'debug' => true,
        'app_id' => 'your-app-id',
        'secret' => 'you-secret',
        'token' => 'easywechat',
        'log' => [
            'level' => 'debug',
            'file' => '/tmp/easywechat.log',
        ]
    ]
];