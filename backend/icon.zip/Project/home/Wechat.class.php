<?php

namespace App\home;

use \Framework\Library\Process\Tool;
use EasyWeChat\Foundation\Application;


/**
 * 默认首页控制器
 * Class Wechat
 * @package App\Home
 */
class Wechat
{
    /**
     * @var Application
     */
    public $app;

    public function __construct()
    {
        $app = $this->getApp();
    }

    /**
     * 获取easywechat实例
     * @return Application
     */
    public function getApp()
    {
        $options = Config('Wechat');
        $app = new Application($options['wechat']);
        return $app;
    }

    /**
     * 获取鉴权地址
     * @return string
     */
    public function getOauthUrl()
    {
        return $this->app->oauth->redirect()->getTargetUrl();
    }

    /**
     * 获取jssdk
     * @param $url
     * @param null $apiList
     * @param bool $debug
     * @return array|string
     */
    public function getJssdk($url, $apiList = null, $debug = false)
    {
        return $this->app->js->setUrl($url)->config((array)$apiList, $debug, false, false);
    }

    /**
     * 根据前端提供的accesstoken返回用户信息
     * @param $code
     * @return array|null
     */
    public function getUser($code)
    {
        $userInfo = null;
        if (!empty($code)) {
            $app = $this->app;
            $oauth = $app->oauth;
            $token = $oauth->getAccessToken($code);
            $user = $oauth->user($token);
            $user_info_arr = $user->toArray();
            //获取用户基本信息，用户未关注的话将不返回用户的基本信息
            $fans_info = empty($user_info_arr['original']) ? $app->user->get($user->getId())->toArray() : $user_info_arr['original'];
            $userInfo = $fans_info;
            //保存用户信息
            if (!empty($user->getId())) {
                $user = Db('wx_user_data')->select([
                    'where' => ['openid' => $user->getId()]
                ])->find();
                if (!$user) {
                    //图片处理
                    $insert = Db('wx_user_data')->insert([
                        'openid' => $user->getId(),
                        'username' => $user->getNickname(),
                        'icon' => $user->getAvatar(),
                        'icon_operate_count' => 0,
                        'created_at' => time(),
                        'updated_at' => time()
                    ]);
                }
            }
        }
        return $userInfo;
    }

}