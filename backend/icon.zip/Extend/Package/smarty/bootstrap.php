<?php
if (!class_exists('Smarty_Autoloader')) {
    require dirname(__FILE__) . '/Autoloader.php';
}
Smarty_Autoloader::register(true);
